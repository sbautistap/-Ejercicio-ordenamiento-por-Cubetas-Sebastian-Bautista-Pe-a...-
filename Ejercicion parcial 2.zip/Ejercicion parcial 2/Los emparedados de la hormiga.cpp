
/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

int main(int argc, char** argv) {
	
	int cant_tros;
	int trozos [100];
	int suma;
	int cuenta;
	int control;
	
	
	//aqui debo validar que no sea mas de 100 trozos
	

	cout<<"Cuantos trozos hay? ";
	cin>>cant_tros;
	
	while (cant_tros>100){
	
	    cout << "El número ingresado es mayor a 100. Por favor, ingrese un número menor a 100." <<endl;
	    cin>> cant_tros;
	    
	}
	

	//ciclo para repetir el tamaño de cada trozo
	
	for (cuenta=0;cuenta<cant_tros;cuenta++){
		
		cout<<"digite el tamaño del trozo numero "<<(cuenta+1)<<" : ";
		cin>>trozos[cuenta];
	}
	
	for (cuenta=0;cuenta<cant_tros;cuenta++){
		control=trozos[cuenta];
		suma=0;
		for (int recorre=cuenta+1;recorre<cant_tros;recorre++){
			suma+=trozos[recorre];
			
			//aqui puedo implementar una forma para salir del for	
		}
		if (control==suma){
			
			cout<<"Si se puede hacer un emparedado, con la posicion: "<<(cuenta+1)<<" Tapa superior "<<endl;
			cuenta=cant_tros;
		}
			//como saber que tengo que decir no
		
	    if (control=!suma){
	        cout<<"NO se pueden hacer emparedados con los trozos dados"<<endl;
	    }

	
	}
	return 0;
}



/*cuenta=trozos[0];
	//suma=0;
	suma+=trozos[1];
	if (suma>cuenta){
		cout<<"no me sirve 1";
	}	
	suma+=trozos[2];
	if (suma>cuenta){
		cout<<"no me sirve 2";
	}
	suma+=trozos[3];
	if (suma>cuenta){
		cout<<"no me sirve 3";
	}
	if (suma=cuenta){
		cout<<"encontramos la tapa en la posicion 1";
	}

	cuenta=trozos[1];
	suma=0;
	suma+=trozos[2];
	if (suma>cuenta){
		cout<<"no me sirve 2";
	}
	suma+=trozos[3];
	if (suma>cuenta){
		cout<<"no me sirve 3";
	}
	if (suma=cuenta){
		cout<<"encontramos la tapa en la posicion 2";
	}
	cuenta=trozos[2];
	suma=0;
	suma+=trozos[3];
	if (suma>cuenta){
		cout<<"no me sirve 3";
	}
	if (suma=cuenta){
		cout<<"encontramos la tapa en la posicion 3";
	}*/
	
	
	
	
	//for (cuenta=0;cuenta<cant_tros;cuenta++){
		
		//cout<<"El tamaño del trozo numero   "<<(cuenta+1)<<" : "<<trozos[cuenta]<<endl;
		
//	}

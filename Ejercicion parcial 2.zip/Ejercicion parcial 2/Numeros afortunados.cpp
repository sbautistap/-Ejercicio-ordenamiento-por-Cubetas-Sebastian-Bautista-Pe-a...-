/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

// Ejercicio Numeros afortunados 

#include <iostream>
using namespace std;

void calcularNumerosAfortunados (int n);
void eliminarElemento (int arreglo [], int n, int elementoEliminar);

int main()
{
    
    
    //Elabore una función que reciba un número al cual se le van a calcular los números afortunados y 
    //genere la salida de acuerdo con la explicación dada. 
    
    int n = 1;
    
    while (n != 0){
        cin >> n;
        calcularNumerosAfortunados(n);
    }
    
    return 0;
}

void calcularNumerosAfortunados (int n){
    if (n != 0){
        // 1. Generar el arreglo
        int arreglo [100];
        
        int nCopia = n;
        
        // Llenar
        for (int i = 0; i < n; i++){
            arreglo[i] = i + 1;
        }
        
        
        int m = 2;
        
        while (m < n){
            for (int i = 0; i < n; i = i + m - 1){
                // La ventaja es que nos vamos a parar en los que queremos eliminar
                eliminarElemento(arreglo, n, arreglo[i]);
                n--;
            }
            m++;
        }
        
        // Ordenar
        for (int i = 0; i < n; i++){
            for (int j = i; j < n; j++){
                if (arreglo[j] > arreglo[i]){
                    // Tengo que hacer intercambio
                    int aux = arreglo[i];
                    arreglo[i] = arreglo[j];
                    arreglo[j] = aux;
                }
            }
        }
        
        cout << nCopia <<": ";
        // Probar
        for (int i = 0; i < n; i++){
            cout << arreglo[i] << " ";
        }
        cout << endl;
    }
    
}



void eliminarElemento (int arreglo [], int n, int elementoEliminar){
    for (int i = 0; i < n; i++){
        if (arreglo[i] == elementoEliminar){
            int pos = i;
            
            // Hacer las asignaciones
            for (int j = pos; j < n; j++){
                arreglo[j] = arreglo[j+1];
            }
        }
    }
}

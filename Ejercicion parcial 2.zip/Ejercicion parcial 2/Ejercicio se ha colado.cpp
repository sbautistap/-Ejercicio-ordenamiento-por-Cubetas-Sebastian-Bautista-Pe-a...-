/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

// Ejercicio Numeros afortunados 

#include <iostream>
using namespace std;

    //Elabore una función que reciba los datos de entrada y retorne la cantidad de personas que fueron retiradas
    //de la fila, en la función se debe imprimir los números de los turnos que fueron retirados de la fila.
    


void ejercicioParqueadero(){
    int cantidadCasos;
    cin>>cantidadCasos;
    
  
    int contadorCasos= 0;
    //casos de prueba
    
    while (contadorCasos<cantidadCasos){
        
        int cantidadPersonas=0; 
        cin>>cantidadPersonas;
        
        int arregloParqueaderoCola[cantidadPersonas];
        int contador=0;
        
    //inserto los datos en el arreglo
        while(contador<cantidadPersonas){
            int dato;
            cin>> dato;
            if (dato<= 1000 && dato >0){
                arregloParqueaderoCola[contador]=dato;
                contador;
            }
        }
        
        int contadorLongitud = 0;
        for (int i = 0; i<cantidadPersonas; i++){
            int pivote = arregloParqueaderoCola [i];
            for (int j= i; j < cantidadPersonas; j++){
                if (pivote>arregloParqueaderoCola[j]){
                    contadorLongitud++;
                    break;
                }
            }
        }
        cout << contadorLongitud << endl;
        
        int arregloRespuesta[contadorLongitud];
        int contadorInsertar = 0;
            for (int i =0; i<cantidadPersonas; i++){
                int pivote = arregloParqueaderoCola[i];
                for(int j = i; j<cantidadPersonas;j++){
                    if(pivote>arregloParqueaderoCola[j]){
                        arregloRespuesta[contadorInsertar]=pivote;
                        contadorInsertar++;
                        break;
                    }
                }
            }
            
        for(int i=0;i<contadorLongitud;i++){
                cout<< arregloRespuesta[i] << "  ";
        }
                    
     }
}

int main (){

    ejercicioParqueadero();
}
    return 0;
        
        
        
        
        
    

    
    